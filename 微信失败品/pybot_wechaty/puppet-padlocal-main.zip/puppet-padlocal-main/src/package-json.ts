/**
 * This file will be overwrite when we publish NPM module
 * by scripts/generate_version.ts
 */
import type { PackageJson } from "type-fest";

/**
 * Huan(202108):
 *  The below default values is only for unit testing
 */
export const packageJson: PackageJson = {};
