import { PuppetPadlocal, VERSION } from "./puppet-padlocal.js";

export { VERSION, PuppetPadlocal };
export default PuppetPadlocal;
