# WeChrome

A Chrome extension to unblock Web Version of WeChat


Tired of Tencent for not providing Linux version of WeChat? Run into the following error while logging into web version of WeChat?

```
To protect your account, logging in to WeChat via the web has been suspended. Use WeChat for Windows or WeChat for Mac to log in on a computer. Download WeChat for Windows or Mac at http://wechat.com.
```

This extension bypasses this check!

## how to use

1、Download this project into your pc

2、add offline plugin into your chrome

3、open [https://wx.qq.com/?target=t](https://wx.qq.com/?target=t)


