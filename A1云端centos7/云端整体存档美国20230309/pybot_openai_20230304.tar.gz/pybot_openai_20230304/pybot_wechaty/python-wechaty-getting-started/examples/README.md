# Python Wechaty Examples Directory

## Structure Rules

Please follow the same directory structure from our [TS wechaty-getting-started](https://github.com/wechaty/wechaty-getting-started/tree/master/examples), because we believe that is the best practice for the newcomers who can get to started most easily.

Put your example bot into one of the following directories (the one you believe it's most suitable):

1. `basic/`
1. `advanced/`
1. `professional/`
1. `third-party/`
